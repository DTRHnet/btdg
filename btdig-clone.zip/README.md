# BTDigg Clone - BitTorrent DHT Search Engine

A complete clone of the BTDigg BitTorrent DHT search engine, built for educational purposes. This project demonstrates how to create a torrent search engine that crawls the BitTorrent DHT network and provides full-text search capabilities.

## Features

- 🔍 **Full-text Search**: Search through torrent titles and descriptions
- 🌐 **Real-time DHT Analysis**: Continuously crawls the BitTorrent DHT network
- 🔗 **Magnet Links**: Direct magnet link generation for easy downloading
- 📊 **Recent Findings**: View the latest torrents discovered
- 📡 **RSS Feed**: Subscribe to updates via RSS
- 🔧 **OpenSearch Integration**: Add to your browser's search engines
- 🌍 **Multi-language Support**: Available in multiple languages
- 📱 **Responsive Design**: Works on desktop and mobile devices

## Technology Stack

- **Backend**: Python Flask web framework
- **Database**: SQLite with full-text search (FTS5)
- **Frontend**: Vanilla HTML, CSS, and JavaScript
- **Deployment**: Docker containerization
- **Search**: SQLite FTS5 for fast text search

## Quick Start

### Using Docker (Recommended)

1. **Clone the repository**:
   ```bash
   git clone <repository-url>
   cd btdg
   ```

2. **Build and run with Docker Compose**:
   ```bash
   docker-compose up --build
   ```

3. **Access the application**:
   Open your browser and go to `http://localhost:5000`

### Manual Setup

1. **Install Python dependencies**:
   ```bash
   cd backend
   pip install -r requirements.txt
   ```

2. **Initialize the database**:
   ```bash
   python db/seed_data.py
   ```

3. **Run the application**:
   ```bash
   python app.py
   ```

4. **Access the application**:
   Open your browser and go to `http://localhost:5000`

## Project Structure

```
btdg/
├── frontend/                 # Frontend files
│   ├── index.html           # Home page
│   ├── search.html          # Search results page
│   ├── recent.html          # Recent findings page
│   ├── about.html           # About page
│   ├── styles.css           # CSS styles
│   └── script.js            # JavaScript functionality
├── backend/                  # Backend application
│   ├── app.py               # Main Flask application
│   └── requirements.txt     # Python dependencies
├── db/                      # Database files
│   ├── schema.sql           # Database schema
│   └── seed_data.py         # Sample data population
├── infra/                   # Infrastructure files
├── docs/                    # Documentation
├── Dockerfile               # Docker configuration
├── docker-compose.yml       # Docker Compose configuration
├── analysis.json            # Site analysis results
├── tech_stack.json          # Technology stack mapping
└── README.md               # This file
```

## API Endpoints

### Web Pages
- `GET /` - Home page with search form
- `GET /search?q=<query>&p=<page>` - Search results page
- `GET /recent.html` - Recent findings page
- `GET /about/` - About page

### API Endpoints
- `GET /api/search?q=<query>&p=<page>&limit=<limit>` - JSON search API
- `GET /rss.xml` - RSS feed
- `GET /opensearchdescription.xml` - OpenSearch description
- `GET /health` - Health check endpoint

## Database Schema

The application uses SQLite with the following main tables:

- **torrents**: Main torrent information (hash, title, size, etc.)
- **torrents_fts**: Full-text search index
- **statistics**: Application statistics
- **search_history**: Search query analytics

## Configuration

### Environment Variables

- `FLASK_ENV`: Flask environment (development/production)
- `FLASK_DEBUG`: Enable debug mode (0/1)
- `DATABASE`: Database file path

### Application Settings

- `RESULTS_PER_PAGE`: Number of results per page (default: 20)
- `MAX_SEARCH_LENGTH`: Maximum search query length (default: 100)

## Development

### Adding New Features

1. **Frontend**: Add new HTML templates in `frontend/`
2. **Backend**: Add new routes in `backend/app.py`
3. **Database**: Update schema in `db/schema.sql`
4. **Styling**: Modify `frontend/styles.css`

### Testing

```bash
# Run the application in development mode
python backend/app.py

# Test the health endpoint
curl http://localhost:5000/health

# Test search functionality
curl "http://localhost:5000/api/search?q=linux"
```

## Deployment

### Production Deployment

1. **Build the Docker image**:
   ```bash
   docker build -t btdig-clone .
   ```

2. **Run with production settings**:
   ```bash
   docker run -d -p 80:5000 --name btdig-clone btdig-clone
   ```

### Using Docker Compose

```bash
# Production deployment
docker-compose -f docker-compose.prod.yml up -d

# Development deployment
docker-compose up --build
```

## Security Considerations

- Input sanitization for search queries
- Rate limiting for API endpoints
- HTTPS enforcement in production
- SQL injection prevention through parameterized queries
- XSS protection through proper output encoding

## Legal Notice

This is a demonstration clone of BTDigg created for educational purposes. The original BTDigg service and this clone are search engines that index publicly available torrent metadata. We do not host, store, or distribute any copyrighted content. Users are responsible for ensuring they have the right to download any content they access.

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- Original BTDigg service for inspiration
- Flask web framework
- SQLite for database functionality
- Font Awesome for icons

## Support

For issues and questions:
1. Check the documentation
2. Search existing issues
3. Create a new issue with detailed information

---

**Note**: This is a demo/educational project. For production use, ensure compliance with local laws and regulations regarding torrent indexing and distribution.
